#!/bin/sh
cd "/home/pi/Python CCS Total Scoreboard/"
python3 CalcCSV.py > service.log
