import requests, re
url = "http://scoreboard2.uscyberpatriot.org/index.php"
devurl = "http://localhost:8008/index.php"
# url = devurl #Comment for real thing

print("Fetching Url: " + url)

webdata = ""
tries = 0
while tries < 5:
    try:
        webdata = requests.get(url).content.decode()
        try:
            responsefile = open("Web/response.html","w")
            responsefile.write(webdata)
            responsefile.close()
        except Exception as ex:
            print("Error when saving response: " + str(ex))
        print("Parsing Webpage")
        webdata = webdata.split('<table cellspacing="0" cellpadding="0" class="CSSTableGenerator"><tbody>')[1].split("</tbody></table>")[0]
        tries = 6
    except Exception as ex:
        tries += 1
        print("Failed to fetch webpage. [%s/5]" % str(tries))
        print("Error: " + str(ex))
if tries == 5:
    raise Exception("Failed to fetch scoreboard.")


webdata = re.sub('<tr [^>]+>', ' ', webdata).split("</tr>\n")

if not 'href="index.php' in webdata[0]:
    raise Exception("Invalid scoreboard page (not index.php)")

csvfile = open("Round3.csv","w")
csvfile.write("Team Number,Scored Images,CCS Score\n")
for i in range(1,len(webdata)):
    row = webdata[i].replace("</td>","").split("<td>")
    if len(row) >= 5:
        csvfile.write("%s,%s,%s\n" % (row[1],row[2],row[4]))
csvfile.close()

print("CSV File Saved.")

print("Done.")
