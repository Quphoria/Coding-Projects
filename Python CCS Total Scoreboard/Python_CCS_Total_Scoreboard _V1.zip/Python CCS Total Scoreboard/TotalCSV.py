import sqlitedb_IO
DB = sqlitedb_IO.DB()
DB.load()
tables = []

# tablename,filename,comp_round,senior_images
rounds = [["Round1","Round1.csv",1,2],["Round2","Round2.csv",2,3],["Round3","Round3.csv",2,3]]

for round in rounds:
    tablename = round[0]
    filename = round[1]
    comp_round = round[2]
    senior_images = round[3]
    tables.append(tablename)
    print("Opening: " + filename)
    try:
        csvfile = open(filename,"r")
        data = []
        csvfiledata = csvfile.readlines()
        csvfile.close()
        try:
            assert csvfiledata[0] == "Team Number,Scored Images,CCS Score\n"
            for i in range(1,len(csvfiledata)):
                row = csvfiledata[i].replace("\n","")
                if row:
                    rowdata = row.split(",")
                    category = 1
                    if int(rowdata[1]) == senior_images:
                        category = 2
                    data.append((rowdata[0],category,rowdata[2],comp_round))
        except Exception as ex:
            print("Invalid CSV file: " + filename + ", Error: " + str(ex))
        try:
            DB.run_sql("""
                DROP TABLE IF EXISTS %s;
            """ % tablename)
        except Exception as ex:
            print("Error when dropping table: " + tablename + ", Error: "+ str(ex))
        DB.run_sql('''CREATE TABLE %s
                      ("Team" text, "Scored Images Category" real, "CCS Score" real, "Round" real)
                ''' % tablename)
        print("Inserting values into DB")
        DB.run_many_sql('INSERT INTO %s VALUES (?,?,?,?)' % tablename, data)
    except Exception as ex:
        print("Error with " + tablename + ", Error: " + str(ex))

for tablename in tables:
    DB.run_sql('''CREATE TABLE IF NOT EXISTS %s
                  ("Team" text, "Scored Images Category" real, "CCS Score" real, "Round" real)
            ''' % tablename)

print("Saving DB")
DB.save()
print("Calculating Totals and Saving CSV Files")
totals_sql = """
SELECT un.Team, Max(un.[Scored Images Category]) AS [Max Scored Images Category], Sum(un.[CCS Score]) AS [Total CCS Score]
FROM (
  SELECT [Team], [Scored Images Category], [CCS Score], [Round]
  FROM [Round1]
  UNION SELECT [Team], [Scored Images Category], [CCS Score], [Round]
  FROM [Round2]
  UNION SELECT [Team], [Scored Images Category], [CCS Score], [Round]
  FROM [Round3]
) AS un
GROUP BY un.Team
ORDER BY Sum(un.[CCS Score]) DESC;
"""

totals_category_sql = """
SELECT un.Team, Max(un.[Scored Images Category]) AS [Max Scored Images Category], Sum(un.[CCS Score]) AS [Total CCS Score]
FROM (
  SELECT [Team], [Scored Images Category], [CCS Score], [Round]
  FROM [Round1]
  UNION SELECT [Team], [Scored Images Category], [CCS Score], [Round]
  FROM [Round2]
  UNION SELECT [Team], [Scored Images Category], [CCS Score], [Round]
  FROM [Round3]
) AS un
GROUP BY un.Team
HAVING [Max Scored Images Category] = ?
ORDER BY Sum(un.[CCS Score]) DESC;
"""


category_lookup = {1:"Junior",2:"Senior"}

csvfile = open("Totals.csv","w")
csvfile.write("Team ID,Scored Images Category,Total CCS Score\n")
data = DB.run_sql(totals_sql)
for i in data:
    csvfile.write("%s,%s,%s\n" % (i[0],category_lookup[i[1]],i[2]))
csvfile.close()

csvfile = open("JuniorTotals.csv","w")
csvfile.write("Team ID,Scored Images Category,Total CCS Score\n")
data = DB.run_sql(totals_category_sql,(1,))
for i in data:
    csvfile.write("%s,%s,%s\n" % (i[0],category_lookup[i[1]],i[2]))
csvfile.close()

csvfile = open("SeniorTotals.csv","w")
csvfile.write("Team ID,Scored Images Category,Total CCS Score\n")
data = DB.run_sql(totals_category_sql,(2,))
for i in data:
    csvfile.write("%s,%s,%s\n" % (i[0],category_lookup[i[1]],i[2]))
csvfile.close()

print("Closing DB")
DB.exit()
print("Done.")
